import java.util.Scanner;

public class Demo 
{
public static void main(String args[])
{
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter a number:");
	int marks=scan.nextInt();
	System.out.println("welcome to kodnest");
Demo2 demo2=new Demo2();
demo2.checkmarks(marks);



}
 
}

