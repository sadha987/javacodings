
public class Demo2 {
  void checkmarks(int marks)
	{
		if(marks>=80)
		{
			System.out.println("Welcome to TechClub");
		}
		
	}
}
