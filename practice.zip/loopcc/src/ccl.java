public class ccl
{
	public static void main(String args[])
	{ int i=1;
		while(i<=5)
		{
			int j=1;
			do
			{
			System.out.print("kodnest");
			j++;
			}while(j<=5);
			i++;
			System.out.println();
		}
		System.out.println("technologies");
	}
}
