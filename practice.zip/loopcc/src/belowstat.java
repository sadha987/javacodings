
public class belowstat {
public static void main(String args[])
{

int i=0;
continue;

while(i<=5)
{
	System.out.println("kodnest");
}
}
}
