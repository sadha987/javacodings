package regsys;

import java.util.Scanner;

public class RegistrationSystem {
public static void main(String arg[])
{
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter user input");
boolean userinput =scan.hasNext();
System.out.println(userinput);
}
static void isValidInput(boolean userinput , boolean condition)
{
	 userinput = true||false;
	
if (userinput =true )
{
	System.out.println("input is valid");
}
if( userinput && condition)
	{
	System.out.println("input is valid");
	}
	
}
}